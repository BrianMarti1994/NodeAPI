
//GetUsers
exports.GetUser = (req, res)=>{
    try {
        res.send("From Controller")
    } catch (error) {
        
    }
}

//Add Users
exports.SaveUser = (req, res)=>{
    try {
        res.send(req.body)
    } catch (error) {
        
    }
 }