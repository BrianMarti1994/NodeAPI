const express = require("express");
const bodyParser = require("body-parser");

var app = express();
app.use(express.static("public"));
app.use(bodyParser.json());
// ===================Register Routes=================
 const userRouter =  require("./Routes/userHandler")
 
 //Inilisize Routes 
 app.use("/api",userRouter)




app.listen(7000,()=>{
    console.log("Server Started")
})

module.exports = app;