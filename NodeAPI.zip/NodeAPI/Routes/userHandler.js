const express = require("express");

const router = express.Router();

const userController = require('../Controllers/userController');

 router.get("/user/get",userController.GetUser)
 router.post("/user/save",userController.SaveUser)

 //sample test to know is api is working
//  router.get("/test/test",(req,resp)=>{
//     resp.send("Node is working");
// })
module.exports = router

